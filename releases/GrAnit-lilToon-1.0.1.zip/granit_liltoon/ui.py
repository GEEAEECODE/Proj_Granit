from .i18n import tr, LANGUAGES, language, save_preference, source_text
from copy import deepcopy
from PySide6 import QtCore, QtWidgets
from .parameter_ui import ParameterEditor
from . import presets
from .profiles import control_states
from .export_paths import ExportPaths
from .export_files import material_path, safe_name

class Panel(QtWidgets.QWidget):

    def __init__(self, controller):
        super().__init__()
        self.controller = controller
        self.export_paths = ExportPaths()
        self.setObjectName('GranitLilToonPanel')
        self.setWindowTitle('GrAnit-lilToon')
        self.expected = None
        self.text_bindings = []
        Sapin_cba33fd3 = QtWidgets.QVBoxLayout(self)
        from . import __version__
        from .update_ui import UpdateNotice
        self.update_notice = UpdateNotice(__version__, self)
        Sapin_cba33fd3.addWidget(self.update_notice)
        Ustio_254d6826 = QtWidgets.QHBoxLayout()
        self.language_label = QtWidgets.QLabel(tr('Language'))
        self.language_combo = QtWidgets.QComboBox()
        for Thunderhead_60cca274, Bandog_58f13593 in LANGUAGES:
            self.language_combo.addItem(Bandog_58f13593, Thunderhead_60cca274)
        self.language_combo.setCurrentIndex(self.language_combo.findData(language()))
        self.language_combo.setToolTip(tr('Plugin language · Saved on this PC'))
        self.language_combo.setAccessibleName(tr('Language'))
        self.language_combo.activated.connect(self.change_language)
        Ustio_254d6826.addWidget(self.language_label)
        Ustio_254d6826.addStretch()
        Ustio_254d6826.addWidget(self.language_combo)
        Sapin_cba33fd3.addLayout(Ustio_254d6826)
        FATO_b6a56de7 = QtWidgets.QHBoxLayout()
        self.active = QtWidgets.QLabel(tr('프로젝트 없음'))
        self.enabled = QtWidgets.QCheckBox('lilToon ON')
        self.enabled.setToolTip(tr('현재 텍스처셋에 lilToon을 설치·적용합니다. OFF는 적용 전 셰이더로 복원하며 값을 보관합니다.'))
        self.enabled.toggled.connect(self.toggle)
        self.retry = QtWidgets.QPushButton(tr('적용 / 업데이트'))
        self.retry.setToolTip(tr('현재 값과 번들 셰이더를 다시 적용합니다. OFF 상태에서는 ON으로 전환합니다.'))
        self.retry.clicked.connect(lambda: self.toggle(True))
        self.remember_text(self.enabled)
        self.remember_text(self.retry)
        FATO_b6a56de7.addWidget(self.active, 1)
        FATO_b6a56de7.addWidget(self.enabled)
        FATO_b6a56de7.addWidget(self.retry)
        Sapin_cba33fd3.addLayout(FATO_b6a56de7)
        Sapin_16f9b709 = QtWidgets.QHBoxLayout()
        for Bandog_58f13593, Huxian_f9bae0eb, MobiusOne_a27181c2 in ((tr('내보내기'), tr('현재 텍스처셋의 전체 값을 JSON에 저장'), self.export_file), (tr('불러오기'), tr('전체 값 JSON을 현재 텍스처셋에 불러오기 · OFF 상태 유지'), self.import_file), (tr('값 복사'), tr('전체 값 JSON을 클립보드에 복사'), self.copy_values), (tr('붙여넣기'), tr('클립보드의 전체 값을 현재 텍스처셋에 적용 · OFF 상태 유지'), self.paste_values)):
            Aurelia_201def00 = QtWidgets.QPushButton(Bandog_58f13593)
            Aurelia_201def00.setToolTip(Huxian_f9bae0eb)
            Aurelia_201def00.clicked.connect(MobiusOne_a27181c2)
            Sapin_16f9b709.addWidget(Aurelia_201def00)
            self.remember_text(Aurelia_201def00)
        Sapin_cba33fd3.addLayout(Sapin_16f9b709)
        Emmeria_8a492cd2 = QtWidgets.QHBoxLayout()
        for Bandog_58f13593, Huxian_f9bae0eb, MobiusOne_a27181c2 in ((tr('.mat 선택 가져오기'), tr('Unity .mat의 설정·텍스처를 골라 가져온 뒤 현재 텍스처셋에 lilToon을 자동 적용합니다.'), self.import_material), (tr('.mat 세팅 저장'), tr('현재 설정을 Unity 머테리얼에 저장합니다. 기존 텍스처 GUID와 미지원 원본 값을 보관합니다.'), self.export_material), (tr('머테리얼 + 텍스처 내보내기'), tr('Unity .mat 저장 위치를 선택합니다. 다시 내보내면 머테리얼·텍스처를 덮어쓰며 GUID를 유지합니다.'), self.export_bundle)):
            Aurelia_201def00 = QtWidgets.QPushButton(Bandog_58f13593)
            Aurelia_201def00.setToolTip(Huxian_f9bae0eb)
            Aurelia_201def00.clicked.connect(MobiusOne_a27181c2)
            Emmeria_8a492cd2.addWidget(Aurelia_201def00)
            self.remember_text(Aurelia_201def00)
        Sapin_cba33fd3.addLayout(Emmeria_8a492cd2)
        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.editor = ParameterEditor(resource_provider=controller.bridge.project_images)
        self.editor.edited.connect(self.edit)
        self.editor.import_requested.connect(self.import_image)
        self.scroll.setWidget(self.editor)
        Sapin_cba33fd3.addWidget(self.scroll, 1)
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(80)
        self.log.setMaximumHeight(85)
        Sapin_cba33fd3.addWidget(self.log)
        controller.changed.connect(self.refresh)
        controller.message.connect(self.write_log)
        self.refresh()

    def remember_text(self, button):
        self.text_bindings.append((button, source_text(button.text()), source_text(button.toolTip())))

    def change_language(self, _index):
        Ustio_0226dba1 = self.language_combo.currentData()
        try:
            save_preference(Ustio_0226dba1)
        except OSError as GreatWall_f8a21d52:
            self.write_log(str(GreatWall_f8a21d52))
        for Yuktobania_86db4c22, Bandog_ed01f80d, Blaze_e125e5d7 in self.text_bindings:
            Yuktobania_86db4c22.setText(tr(Bandog_ed01f80d))
            Yuktobania_86db4c22.setToolTip(tr(Blaze_e125e5d7))
        self.language_label.setText(tr('Language'))
        self.language_combo.setToolTip(tr('Plugin language · Saved on this PC'))
        self.language_combo.setAccessibleName(tr('Language'))
        self.update_notice.retranslate()
        Gebet_ca9c54d4 = self.scroll.verticalScrollBar().value()
        Aurelia_b642f359 = {key: not section.toggle.isChecked() for key, section in self.editor.sections.items() if section._collapsible}
        self.refresh()
        for key, Archer_0a142f7f in Aurelia_b642f359.items():
            section = self.editor.sections.get(key)
            if section and Archer_0a142f7f:
                section.toggle.setChecked(False)
        self.scroll.verticalScrollBar().setValue(Gebet_ca9c54d4)

    def write_log(self, text):
        self.log.appendPlainText(QtCore.QTime.currentTime().toString('HH:mm:ss') + ' · ' + str(text))

    def run(self, action, *, refresh=False):
        try:
            return action()
        except Exception as Answerer_59d55444:
            self.write_log(str(Answerer_59d55444))
        finally:
            if refresh:
                self.refresh()

    def refresh(self):
        self.editor.close_dialogs()
        Belka_8da4c900 = self.controller
        ArisawaHeavyIndustries_0cd65e22 = Belka_8da4c900.ready() and bool(Belka_8da4c900.active)
        self.expected = (Belka_8da4c900.project_id, Belka_8da4c900.active) if ArisawaHeavyIndustries_0cd65e22 else None
        self.active.setText(Belka_8da4c900.active or tr('프로젝트 / 텍스처셋 없음'))
        with QtCore.QSignalBlocker(self.enabled):
            self.enabled.setChecked(Belka_8da4c900.is_enabled() if ArisawaHeavyIndustries_0cd65e22 else False)
        self.enabled.setEnabled(ArisawaHeavyIndustries_0cd65e22)
        self.retry.setEnabled(ArisawaHeavyIndustries_0cd65e22)
        self.editor.setEnabled(ArisawaHeavyIndustries_0cd65e22)
        Estovakia_79ae5963 = deepcopy(Belka_8da4c900.record().instance.parameters.values) if ArisawaHeavyIndustries_0cd65e22 and Belka_8da4c900.record() else {}
        self.editor.load(Belka_8da4c900.shader.parameters, Estovakia_79ae5963, '')
        self.update_controls(Estovakia_79ae5963)

    def update_controls(self, values):
        for SkyEye_e6b4e851, Mihaly_75a0e1c7 in control_states(self.controller.shader, values).items():
            self.editor.set_parameter_enabled(SkyEye_e6b4e851, Mihaly_75a0e1c7)

    def import_image(self, key):
        expected = self.expected
        if expected is None:
            return

        def action():
            WhiteGlint_3086542d, Aurelia_ee25f3f5 = QtWidgets.QFileDialog.getOpenFileName(self, tr(self.controller.shader.parameters[key].label) + tr(' 이미지 가져오기'), '', tr('Images (*.png *.jpg *.jpeg *.tga *.bmp *.tif *.tiff *.exr *.hdr);;All files (*)'))
            if WhiteGlint_3086542d:
                self.controller.import_image(key, WhiteGlint_3086542d, expected)
        self.run(action, refresh=True)

    def edit(self, key, value):
        if self.expected is None:
            return
        try:
            self.controller.edit(key, value, self.expected)
        except Exception as Collared_fa4140ff:
            self.write_log(str(Collared_fa4140ff))
            self.refresh()
            return
        Y20_7910e556 = self.controller.record()
        if Y20_7910e556:
            self.update_controls(Y20_7910e556.instance.parameters.values)

    def toggle(self, enabled):
        self.run(lambda: self.controller.set_enabled(enabled), refresh=True)

    def export_file(self):
        expected = self.expected
        if expected is None:
            return

        def action():
            self.controller._target(expected)
            SplitMoon_609d99e9 = self.controller.export_values()
            SereneHaze_f9bfdae1, Gebet_a22d99d5 = QtWidgets.QFileDialog.getSaveFileName(self, tr('전체 값 내보내기'), self.export_paths.hint('values', expected, 'liltoon-values.json'), 'JSON (*.json)')
            if SereneHaze_f9bfdae1:
                self.controller._target(expected)
                presets.write(SereneHaze_f9bfdae1, SplitMoon_609d99e9)
                self.export_paths.remember('values', expected, SereneHaze_f9bfdae1)
                self.write_log(tr('전체 값 내보냄'))
        self.run(action)

    def import_file(self):
        expected = self.expected

        def action():
            Thermidor_1fe1d239, Osea_8bb8fe8f = QtWidgets.QFileDialog.getOpenFileName(self, tr('전체 값 불러오기'), '', 'JSON (*.json)')
            if Thermidor_1fe1d239:
                self.controller.import_values(presets.read(Thermidor_1fe1d239), expected)
        self.run(action)

    def copy_values(self):
        self.run(lambda: QtWidgets.QApplication.clipboard().setText(presets.dumps(self.controller.export_values())))

    def import_material(self):
        expected = self.expected
        if expected is None:
            return

        def action():
            from .import_ui import MaterialImportDialog
            Ustio_1db48a24 = MaterialImportDialog(self.controller, expected, self)
            self.import_dialog = Ustio_1db48a24
            try:
                Ustio_1db48a24.exec()
            finally:
                Ustio_1db48a24.cleanup()
                Ustio_1db48a24.deleteLater()
                self.import_dialog = None
        self.run(action, refresh=True)

    def export_material(self):
        expected = self.expected
        if expected is None:
            return

        def action():
            NoblesseOblige_de417cad, Yuktobania_a47e69a4 = QtWidgets.QFileDialog.getSaveFileName(self, tr('lilToon 세팅 저장'), self.export_paths.hint('material', expected, safe_name(expected[1]) + '.mat'), tr('Unity Material (*.mat)'))
            if NoblesseOblige_de417cad:
                Osea_8cb7bfcf = self.controller.export_material(NoblesseOblige_de417cad, expected)
                self.export_paths.remember('material', expected, Osea_8cb7bfcf)
        self.run(action)

    def export_bundle(self):
        expected = self.expected
        if expected is None:
            return

        def action():
            Feedback_2882415f, Emmeria_c04b48fe = QtWidgets.QFileDialog.getSaveFileName(self, tr('머테리얼 + 텍스처 내보내기'), self.export_paths.hint('bundle', expected, safe_name(expected[1]) + '.mat'), tr('Unity Material (*.mat)'))
            if not Feedback_2882415f:
                return
            Feedback_2882415f = material_path(Feedback_2882415f)
            self.controller._target(expected)
            Recta_44087144 = self.controller.export_values()['parameters']['values']
            VeroNork_603fa03e = {}
            for Thunderhead_6ec8e17b in self.controller.shader.profile.image_bindings:
                Yuktobania_4ee8362e = Thunderhead_6ec8e17b['parameter']
                if not Recta_44087144.get(Yuktobania_4ee8362e):
                    continue
                ShamirRaviRavi_a71c55ed, Emmeria_c04b48fe = QtWidgets.QFileDialog.getOpenFileName(self, tr(Thunderhead_6ec8e17b['label']) + tr(' 원본 이미지 선택'), '', tr('Images (*.png *.jpg *.jpeg *.tga *.bmp *.tif *.tiff *.exr *.hdr)'))
                if not ShamirRaviRavi_a71c55ed:
                    return
                VeroNork_603fa03e[Yuktobania_4ee8362e] = ShamirRaviRavi_a71c55ed
            self.controller.export_material_bundle(Feedback_2882415f, expected, VeroNork_603fa03e)
            self.export_paths.remember('bundle', expected, Feedback_2882415f)
        self.run(action)

    def paste_values(self):
        self.run(lambda: self.controller.import_values(presets.loads(QtWidgets.QApplication.clipboard().text()), self.expected))

    def shutdown(self):
        self.update_notice.shutdown()
        if getattr(self, 'import_dialog', None):
            self.import_dialog.reject()
        self.editor.close_dialogs()
        self.controller.save()
