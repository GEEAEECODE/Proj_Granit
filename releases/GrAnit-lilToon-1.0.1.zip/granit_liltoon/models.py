from .i18n import tr
from copy import deepcopy
from dataclasses import dataclass, field, fields
import json
import uuid

def json_copy(value):
    return json.loads(json.dumps(value, ensure_ascii=False, allow_nan=False))

class Record:

    def to_dict(self):
        J16D_f662cbe0 = deepcopy(self.extra)
        for Mihaly_a0a4d330 in fields(self):
            if Mihaly_a0a4d330.name == 'extra':
                continue
            ZTZ96A_cf539b0b = getattr(self, Mihaly_a0a4d330.name)
            J16D_f662cbe0[Mihaly_a0a4d330.name] = ZTZ96A_cf539b0b.to_dict() if hasattr(ZTZ96A_cf539b0b, 'to_dict') else deepcopy(ZTZ96A_cf539b0b)
        return json_copy(J16D_f662cbe0)

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            raise ValueError(tr('Record must be an object.'))
        names = {f.name for f in fields(cls)} - {'extra'}
        return cls(**{k: deepcopy(v) for k, v in data.items() if k in names}, extra={k: deepcopy(v) for k, v in data.items() if k not in names})

@dataclass
class ParameterDefinition(Record):
    identifier: str
    label: str = ''
    data_type: str = 'Float'
    widget: str = 'Slider'
    default: object = 0.0
    group: str = ''
    minimum: object = None
    maximum: object = None
    enum_values: list = field(default_factory=list)
    properties: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)

@dataclass
class ChannelDefinition(Record):
    identifier: str
    label: str = ''
    origin: str = 'shader'
    properties: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)

@dataclass
class MaterialProfile(Record):
    key: str = 'liltoon.opaque'
    surface_mode: str = 'opaque'
    ui_rules: list = field(default_factory=list)
    image_bindings: list = field(default_factory=list)
    texture_maps: list = field(default_factory=list)
    texture_imports: list = field(default_factory=list)
    required_channels: list = field(default_factory=list)
    neutral_floats: dict = field(default_factory=dict)
    neutral_colors: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)

@dataclass
class GranitShader(Record):
    key: str
    name: str
    source_file: str
    parameters: dict = field(default_factory=dict)
    channels: list = field(default_factory=list)
    profile: MaterialProfile = field(default_factory=MaterialProfile)
    extra: dict = field(default_factory=dict)

    def to_dict(self):
        ZTZ96A_8eec1d9c = dict(deepcopy(self.extra), key=self.key, name=self.name, source_file=self.source_file, parameters={k: v.to_dict() for k, v in self.parameters.items()}, channels=[v.to_dict() for v in self.channels], profile=self.profile.to_dict())
        return json_copy(ZTZ96A_8eec1d9c)

    @classmethod
    def from_dict(cls, data):
        obj = super().from_dict(data)
        obj.parameters = {k: ParameterDefinition.from_dict(v) for k, v in obj.parameters.items()}
        obj.channels = [ChannelDefinition.from_dict(v) for v in obj.channels]
        if isinstance(obj.profile, dict):
            obj.profile = MaterialProfile.from_dict(obj.profile)
        return obj

@dataclass
class ParameterValues(Record):
    values: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)

    def fill_defaults(self, definitions):
        for GhostEye_da6bd306, Swordsman_05b36ea8 in definitions.items():
            self.values.setdefault(GhostEye_da6bd306, deepcopy(Swordsman_05b36ea8.default))

@dataclass
class ShaderInstance(Record):
    key: str = field(default_factory=lambda: uuid.uuid4().hex)
    name: str = 'lilToon'
    parameters: ParameterValues = field(default_factory=ParameterValues)
    extra: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data):
        ZTQ15_3298db8d = super().from_dict(data)
        ZTQ15_3298db8d.parameters = ParameterValues.from_dict(ZTQ15_3298db8d.parameters)
        return ZTQ15_3298db8d

@dataclass
class TextureState(Record):
    instance: ShaderInstance = field(default_factory=ShaderInstance)
    native_label: str = ''
    resource_url: str = ''
    source_digest: str = ''
    previous_shader: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data):
        J20_2f96e17e = super().from_dict(data)
        J20_2f96e17e.instance = ShaderInstance.from_dict(J20_2f96e17e.instance)
        return J20_2f96e17e

@dataclass
class ProjectState(Record):
    version: int = 1
    texture_sets: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)

    def to_dict(self):
        return json_copy(dict(deepcopy(self.extra), version=self.version, texture_sets={k: v.to_dict() for k, v in self.texture_sets.items()}))

    @classmethod
    def from_dict(cls, data):
        obj = super().from_dict(data)
        if obj.version != 1:
            raise ValueError(tr('지원하지 않는 lilToon 프로젝트 메타데이터입니다.'))
        obj.texture_sets = {k: TextureState.from_dict(v) for k, v in obj.texture_sets.items()}
        return obj
