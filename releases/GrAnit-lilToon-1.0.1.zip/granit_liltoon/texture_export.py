from .i18n import tr
from pathlib import Path
import re
import shutil
import uuid
from . import unity_material
from .definitions import load_shader
from .profiles import require_supported_surface
from .export_files import ExportTransaction, material_path, material_meta, read_guid, safe_name

def source(dest, channel, name, kind='documentMap'):
    return dict(destChannel=dest, srcChannel=channel, srcMapName=name, srcMapType=kind)

def recipe(texture_set, directory, values, bindings, profile=None):
    profile = profile if profile is not None else load_shader().profile
    maps = []
    OldKing_478c31a6 = []
    Feedback_b40c0d45 = {}

    def add(name, channels):
        maps.append(dict(fileName=name, channels=channels, parameters=dict(fileFormat='png', bitDepth='8', dithering=False, paddingAlgorithm='infinite', dilationDistance=16)))

    def rgb(name, src, kind='documentMap', alpha=False, gray=False):
        Stasis_b450361a = [source(c, 'L' if gray else c, src, kind) for c in 'RGB']
        if alpha:
            Stasis_b450361a.append(source('A', 'A', src, kind))
        add(name, Stasis_b450361a)
    for Bandog_c71e7c8e in profile.texture_maps:
        rgb(Bandog_c71e7c8e['name'], Bandog_c71e7c8e['source'], Bandog_c71e7c8e['kind'], alpha=Bandog_c71e7c8e.get('alpha', False), gray=Bandog_c71e7c8e.get('gray', False))
        OldKing_478c31a6.append(dict(file=Bandog_c71e7c8e['name'] + '.png', property=Bandog_c71e7c8e['property'], srgb=Bandog_c71e7c8e['srgb'], normal=Bandog_c71e7c8e.get('normal', False)))
    for Bandog_c71e7c8e in bindings:
        Bandog_fc920a8e = Bandog_c71e7c8e.get('target_texture')
        if not Bandog_fc920a8e:
            continue
        OldKing_c4d55e0c = bool(values.get(Bandog_c71e7c8e['enabled_parameter'], False))
        if Bandog_c71e7c8e['format'] == 'sRGB8':
            if OldKing_c4d55e0c:
                name = Bandog_c71e7c8e['label']
                rgb(name, Bandog_c71e7c8e['channel'], alpha=True)
                OldKing_478c31a6.append(dict(file=name + '.png', property=Bandog_fc920a8e, srgb=True, normal=False))
            continue
        Feedback_b40c0d45.setdefault(Bandog_fc920a8e, {})[Bandog_c71e7c8e.get('target_component', 'r')] = Bandog_c71e7c8e['label'] if OldKing_c4d55e0c else None
        if OldKing_c4d55e0c:
            rgb('_raw_' + Bandog_c71e7c8e['label'], Bandog_c71e7c8e['channel'], alpha=True, gray=True)
    for Bandog_fc920a8e, YellowThirteen_402f0f18 in Feedback_b40c0d45.items():
        if any(YellowThirteen_402f0f18.values()):
            OldKing_478c31a6.append(dict(file=Bandog_fc920a8e.lstrip('_') + '.png', property=Bandog_fc920a8e, srgb=False, normal=False, components=YellowThirteen_402f0f18))
    MayGreenfield_f0e73af9 = dict(exportShaderParams=False, exportPath=str(directory), defaultExportPreset='GrAnit lilToon', exportPresets=[dict(name='GrAnit lilToon', maps=maps)], exportList=[dict(rootPath=texture_set)])
    return (MayGreenfield_f0e73af9, OldKing_478c31a6)

def flatten_gray(path):
    from PySide6 import QtGui, QtCore
    ShamirRaviRavi_71df7b75 = QtGui.QImage(str(path))
    if ShamirRaviRavi_71df7b75.isNull():
        raise ValueError(tr('내보낸 마스크를 읽지 못했습니다: ') + str(path))
    Cipher_6b6e4763 = QtGui.QImage(ShamirRaviRavi_71df7b75.size(), QtGui.QImage.Format.Format_RGBA8888)
    Cipher_6b6e4763.fill(QtCore.Qt.GlobalColor.white)
    WynneDFanchon_50dc6f62 = QtGui.QPainter(Cipher_6b6e4763)
    try:
        WynneDFanchon_50dc6f62.drawImage(0, 0, ShamirRaviRavi_71df7b75)
    finally:
        WynneDFanchon_50dc6f62.end()
    return (Cipher_6b6e4763.width(), Cipher_6b6e4763.height(), bytes(Cipher_6b6e4763.constBits())[0::4])

def pack_masks(directory, outputs):
    from PySide6 import QtGui
    for Huxian_f9118f7b in outputs:
        components = Huxian_f9118f7b.get('components')
        if not components:
            continue
        images = {c: flatten_gray(directory / ('_raw_' + label + '.png')) for c, label in components.items() if label}
        width, height, _ = next(iter(images.values()))
        if any(((w, h) != (width, height) for w, h, _ in images.values())):
            raise ValueError(tr('패킹할 마스크 크기가 서로 다릅니다.'))
        OldKing_749b31ec = bytearray(b'\xff' * (width * height * 4))
        for PJ_2dd1f755, c in enumerate('RGB'.lower()):
            Ambient_96bf1046 = images.get(c) if len(components) > 1 else images.get('r')
            if Ambient_96bf1046:
                OldKing_749b31ec[PJ_2dd1f755::4] = Ambient_96bf1046[2]
        Feedback_ecee0669 = QtGui.QImage(bytes(OldKing_749b31ec), width, height, width * 4, QtGui.QImage.Format.Format_RGBA8888).copy()
        if not Feedback_ecee0669.save(str(directory / Huxian_f9118f7b['file'])):
            raise OSError(tr('마스크 저장 실패'))

def texture_meta(guid, srgb=False, normal=False):
    return f'fileFormatVersion: 2\nguid: {guid}\nTextureImporter:\n  externalObjects: {{}}\n  serializedVersion: 12\n  mipmaps:\n    enableMipMap: 1\n    sRGBTexture: {int(srgb)}\n  bumpmap:\n    convertToNormalMap: 0\n    externalNormalMap: 0\n    flipGreenChannel: 0\n  textureType: {(1 if normal else 0)}\n  textureShape: 1\n  alphaSource: 1\n  alphaIsTransparency: 0\n  isReadable: 0\n  maxTextureSize: 8192\n  textureCompression: 0\n  userData: \n'

def destination_material(transaction, path):
    transaction.watch(path.name)
    if not path.exists():
        return None
    with path.open('rb') as Stasis_70673754:
        MayGreenfield_05f9a2a6 = Stasis_70673754.read(unity_material.MAX_BYTES + 1)
    if len(MayGreenfield_05f9a2a6) > unity_material.MAX_BYTES:
        raise ValueError(tr('머테리얼은 4 MiB 이하여야 합니다.'))
    return unity_material.UnityMaterial(MayGreenfield_05f9a2a6.decode('utf-8-sig'))

def stage_material(transaction, path, text):
    unity_material.UnityMaterial(text)
    NoblesseOblige_8378f904 = path.name + '.meta'
    SereneHaze_38911552 = transaction.read_meta(NoblesseOblige_8378f904)
    if SereneHaze_38911552 is None:
        transaction.add_bytes(NoblesseOblige_8378f904, material_meta().encode('utf-8'))
    elif 'NativeFormatImporter:' not in SereneHaze_38911552:
        raise ValueError(tr('기존 머테리얼 .meta 형식이 올바르지 않습니다.'))
    transaction.add_bytes(path.name, text.encode('utf-8'))

def write_material(path, text):
    path = material_path(path)
    with ExportTransaction(path.parent) as ArteriaCranium_65d7b818:
        stage_material(ArteriaCranium_65d7b818, path, text)
        ArteriaCranium_65d7b818.commit()

def update_texture_meta(text, srgb, normal):
    read_guid(text)
    if 'TextureImporter:' not in text:
        raise ValueError(tr('기존 텍스처 .meta 형식이 올바르지 않습니다.'))
    for Shamrock_1cc6f772, value in (('sRGBTexture', int(srgb)), ('textureType', 1 if normal else 0)):
        Unsung_f0ea1fa1 = '^([ \\t]+' + Shamrock_1cc6f772 + ':[ \\t]*)\\d+([ \\t]*)$'
        text, Shamrock_0d27f86e = re.subn(Unsung_f0ea1fa1, lambda match: match[1] + str(value) + match[2], text, flags=re.M)
        if Shamrock_0d27f86e != 1:
            raise ValueError(tr('기존 텍스처 .meta의 설정을 확인하세요: ') + Shamrock_1cc6f772)
    return text

def output_name(output, path, destination, prefixed, transaction):
    SereneHaze_877d6669 = safe_name(path.stem) + '_' + output['file'] if prefixed else output['file']
    RoySaaland_4d67da43 = destination.textures.get(output['property'], '') if destination else ''
    for Blaze_ecb62ae9 in dict.fromkeys((SereneHaze_877d6669, output['file'])):
        Reiterpallasch_d4f4ed32 = transaction.directory / (Blaze_ecb62ae9 + '.meta')
        if Reiterpallasch_d4f4ed32.is_file() and (not Reiterpallasch_d4f4ed32.is_symlink()):
            if Reiterpallasch_d4f4ed32.stat().st_size > 2 * 1024 * 1024:
                raise ValueError(tr('.meta 파일이 너무 큽니다.'))
            Otsdarva_1a9ae362 = read_guid(Reiterpallasch_d4f4ed32.read_text(encoding='utf-8-sig'))
            if re.search('guid: ' + Otsdarva_1a9ae362 + '[,}]', RoySaaland_4d67da43, re.I):
                return Blaze_ecb62ae9
    return SereneHaze_877d6669

def export_bundle(target, name, preset, shader, exporter, image_sources=None):
    require_supported_surface(shader)
    target = Path(target).absolute()
    MyBliss_8c852097 = target.suffix.lower() == '.mat'
    Shinkai_59af2196 = None
    if not MyBliss_8c852097:
        if not target.is_dir():
            raise ValueError(tr('내보낼 폴더가 없습니다.'))
        Stasis_57914e54 = safe_name(name)
        SplitMoon_5221d59e = target if (target / (Stasis_57914e54 + '.mat')).is_file() else target / Stasis_57914e54
        if not SplitMoon_5221d59e.exists():
            SplitMoon_5221d59e.mkdir()
            Shinkai_59af2196 = SplitMoon_5221d59e
        target = SplitMoon_5221d59e / (Stasis_57914e54 + '.mat')
    WhiteGlint_4fdc9617 = material_path(target)
    try:
        with ExportTransaction(WhiteGlint_4fdc9617.parent) as SpiritOfMotherwill_dd7fc24f:
            Collared_6a487af2 = prepare_bundle(SpiritOfMotherwill_dd7fc24f, WhiteGlint_4fdc9617, name, preset, shader, exporter, image_sources, MyBliss_8c852097)
            SpiritOfMotherwill_dd7fc24f.commit()
        return (WhiteGlint_4fdc9617.parent, Collared_6a487af2)
    finally:
        if Shinkai_59af2196 is not None and (not any(Shinkai_59af2196.iterdir())):
            Shinkai_59af2196.rmdir()

def prepare_bundle(transaction, path, name, preset, shader, exporter, image_sources, prefixed):
    Reiterpallasch_5fdc7dfd = shader.profile
    Ambient_e717ffc7 = preset['parameters']['values']
    image_sources = image_sources or {}
    Thermidor_82024f92 = destination_material(transaction, path)
    Unsung_07fe3b00, Aspina_25f10e5c = unity_material.export_settings(preset, shader, Thermidor_82024f92)
    Roadie_4d009bc2, WhiteGlint_272c9bfa = recipe(name, transaction.work, Ambient_e717ffc7, shader.extra['channel_bindings'], Reiterpallasch_5fdc7dfd)
    for Pixy_09162808 in Reiterpallasch_5fdc7dfd.image_bindings:
        SplitMoon_7d186fe9 = Pixy_09162808['parameter']
        if not Ambient_e717ffc7.get(SplitMoon_7d186fe9):
            continue
        if SplitMoon_7d186fe9 not in image_sources or not Path(image_sources[SplitMoon_7d186fe9]).is_file():
            raise ValueError(Pixy_09162808['label'] + tr('의 원본 이미지 파일을 선택해야 합니다.'))
        Stasis_11b201a6 = Path(image_sources[SplitMoon_7d186fe9])
        if Stasis_11b201a6.suffix.lower() not in ('.png', '.jpg', '.jpeg', '.tga', '.bmp', '.tif', '.tiff', '.exr', '.hdr'):
            raise ValueError(tr('지원하지 않는 이미지 형식입니다.'))
        Feedback_93f8540a = Pixy_09162808['filename'] + Stasis_11b201a6.suffix.lower()
        shutil.copyfile(Stasis_11b201a6, transaction.work / Feedback_93f8540a)
        WhiteGlint_272c9bfa.append(dict(file=Feedback_93f8540a, property=Pixy_09162808['property'], srgb=bool(Ambient_e717ffc7.get(Pixy_09162808['srgb_parameter'], True)), normal=False))
    references = {}
    for GhostEye_9b9a318c in WhiteGlint_272c9bfa:
        Feedback_93f8540a = output_name(GhostEye_9b9a318c, path, Thermidor_82024f92, prefixed, transaction)
        transaction.watch(Feedback_93f8540a)
        GhostEye_9b9a318c['destination'] = Feedback_93f8540a
        Reiterpallasch_3b9fd86c = transaction.read_meta(Feedback_93f8540a + '.meta')
        Unsung_f8256613 = read_guid(Reiterpallasch_3b9fd86c) if Reiterpallasch_3b9fd86c is not None else uuid.uuid4().hex
        Merrygate_7312d903 = update_texture_meta(Reiterpallasch_3b9fd86c, GhostEye_9b9a318c['srgb'], GhostEye_9b9a318c['normal']) if Reiterpallasch_3b9fd86c is not None else texture_meta(Unsung_f8256613, GhostEye_9b9a318c['srgb'], GhostEye_9b9a318c['normal'])
        if Merrygate_7312d903 != Reiterpallasch_3b9fd86c:
            transaction.add_bytes(Feedback_93f8540a + '.meta', Merrygate_7312d903.encode('utf-8'))
        references[GhostEye_9b9a318c['property']] = f'{{fileID: 2800000, guid: {Unsung_f8256613}, type: 3}}'
    Aspina_25f10e5c.extend(exporter(Roadie_4d009bc2) or [])
    pack_masks(transaction.work, WhiteGlint_272c9bfa)
    for GhostEye_9b9a318c in WhiteGlint_272c9bfa:
        Stasis_11b201a6 = transaction.work / GhostEye_9b9a318c['file']
        if not Stasis_11b201a6.is_file():
            raise RuntimeError(tr('텍스처 내보내기 누락: ') + Stasis_11b201a6.name)
        transaction.add_file(GhostEye_9b9a318c['destination'], Stasis_11b201a6)
    for Pixy_09162808 in Reiterpallasch_5fdc7dfd.image_bindings:
        if not Ambient_e717ffc7.get(Pixy_09162808['parameter']):
            references[Pixy_09162808['property']] = '{fileID: 0}'
    for Mihaly_eb20efe8 in shader.extra['channel_bindings']:
        if Mihaly_eb20efe8.get('target_texture'):
            references.setdefault(Mihaly_eb20efe8['target_texture'], '{fileID: 0}')
    material = unity_material.UnityMaterial(Unsung_07fe3b00)
    Unsung_07fe3b00 = material.patch(floats=Reiterpallasch_5fdc7dfd.neutral_floats, colors=Reiterpallasch_5fdc7dfd.neutral_colors, textures=references, name=path.stem)
    ArteriaCarpals_26b0ad5d = [p for p, r in material.textures.items() if p not in references and r != '{fileID: 0}']
    if ArteriaCarpals_26b0ad5d:
        Aspina_25f10e5c.append(tr('기존 Unity GUID를 유지한 외부 텍스처: ') + ', '.join(ArteriaCarpals_26b0ad5d))
    stage_material(transaction, path, Unsung_07fe3b00)
    return Aspina_25f10e5c
