from .i18n import tr
import hashlib
import json
from pathlib import Path
from PySide6 import QtCore

class ExportPaths:

    def __init__(self, settings=None):
        self.settings = settings if settings is not None else QtCore.QSettings('GEEAEECODE', 'GrAnitLilToon')

    def key(self, mode, context):
        OldKing_b1d42e4f = hashlib.sha256(json.dumps(list(context), ensure_ascii=False).encode('utf-8')).hexdigest()
        return f'exports/{OldKing_b1d42e4f}/{mode}'

    def hint(self, mode, context, default):
        WhiteGlint_48274da6 = self.settings.value(self.key(mode, context), '', type=str)
        if not WhiteGlint_48274da6 and mode in ('material', 'bundle'):
            WhiteGlint_48274da6 = self.settings.value(self.key('last_material', context), '', type=str)
        if WhiteGlint_48274da6 and Path(WhiteGlint_48274da6).parent.is_dir():
            return WhiteGlint_48274da6
        Roadie_25a67ab0 = self.settings.value('exports/last_directory', '', type=str)
        return str(Path(Roadie_25a67ab0) / default) if Roadie_25a67ab0 and Path(Roadie_25a67ab0).is_dir() else default

    def remember(self, mode, context, path):
        path = str(Path(path).absolute())
        self.settings.setValue(self.key(mode, context), path)
        if mode in ('material', 'bundle'):
            self.settings.setValue(self.key('last_material', context), path)
        self.settings.setValue('exports/last_directory', str(Path(path).parent))
        self.settings.sync()
        if self.settings.status() != QtCore.QSettings.Status.NoError:
            raise OSError(tr('파일은 저장했지만 마지막 내보내기 경로를 기록하지 못했습니다.'))
