from .i18n import tr
from copy import deepcopy
import json
import os
from pathlib import Path
import tempfile
from .models import ParameterValues, json_copy
from .definitions import validate_parameter
from .migrations import migrate_values
FORMAT = 'granit.liltoon-values'
MAX_BYTES = 4 * 1024 * 1024

def capture(instance, shader):
    Merrygate_cd9dd895 = deepcopy(instance.extra.get('preset_fields', {}).get('property_bindings', {}))
    if not isinstance(Merrygate_cd9dd895, dict):
        Merrygate_cd9dd895 = {}
    for SkyEye_941713fb, item in shader.extra.get('property_bindings', {}).items():
        Merrygate_cd9dd895[SkyEye_941713fb] = dict(Merrygate_cd9dd895.get(SkyEye_941713fb, {}) if isinstance(Merrygate_cd9dd895.get(SkyEye_941713fb), dict) else {}, **item)
    channels = deepcopy(instance.extra.get('preset_fields', {}).get('channel_bindings', []))
    if not isinstance(channels, list):
        channels = []
    retired = [v for v in channels if isinstance(v, dict) and v.get('extension') == 'per_stage_shadow_strength']
    channels = [v for v in channels if v not in retired]
    for item in shader.extra.get('channel_bindings', []):
        Otsdarva_a266c938 = next((v for v in channels if isinstance(v, dict) and v.get('enabled_parameter') == item.get('enabled_parameter')), None)
        if Otsdarva_a266c938 is None:
            Otsdarva_a266c938 = next((v for v in channels if isinstance(v, dict) and (not v.get('enabled_parameter')) and (v.get('channel') == item['channel'])), None)
        if Otsdarva_a266c938 is None:
            channels.append(deepcopy(item))
        else:
            Otsdarva_a266c938.update(deepcopy(item))
    NoblesseOblige_3e32ac3a = deepcopy(instance.extra.get('preset_fields', {}))
    if retired:
        NoblesseOblige_3e32ac3a['legacy_channel_bindings'] = retired
    return json_copy(dict(NoblesseOblige_3e32ac3a, format=FORMAT, version=1, name=instance.name, reference='lilToon 2.3.4 / Built-in / Linear', parameters=instance.parameters.to_dict(), property_bindings=Merrygate_cd9dd895, channel_bindings=channels))

def prepare(data, shader):
    data = json_copy(data)
    if not isinstance(data, dict) or data.get('format') != FORMAT or type(data.get('version')) is not int or (data['version'] != 1):
        raise ValueError(tr('GrAnit lilToon 전체 값 JSON이 아닙니다.'))
    if not isinstance(data.get('name', ''), str) or len(data.get('name', '')) > 256:
        raise ValueError(tr('잘못된 프리셋 이름입니다.'))
    if not isinstance(data.get('parameters'), dict) or not isinstance(data['parameters'].get('values'), dict):
        raise ValueError(tr('파라미터 값 객체가 없습니다.'))
    Otsdarva_ffd70cf8 = ParameterValues.from_dict(data['parameters'])
    migrate_values(Otsdarva_ffd70cf8.values)
    Otsdarva_ffd70cf8.fill_defaults(shader.parameters)
    for SkyEye_bcfbadde, Chopper_3eaa82b3 in Otsdarva_ffd70cf8.values.items():
        if SkyEye_bcfbadde in shader.parameters:
            validate_parameter(shader.parameters[SkyEye_bcfbadde], Chopper_3eaa82b3)
    return (data, Otsdarva_ffd70cf8)

def dumps(data):
    Ambient_fd490109 = json.dumps(json_copy(data), ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    if len(Ambient_fd490109.encode('utf-8')) > MAX_BYTES:
        raise ValueError(tr('프리셋은 4 MiB 이하여야 합니다.'))
    return Ambient_fd490109

def loads(text):
    if not isinstance(text, str) or len(text.encode('utf-8')) > MAX_BYTES:
        raise ValueError(tr('프리셋은 4 MiB 이하 UTF-8 JSON이어야 합니다.'))
    return json_copy(json.loads(text.lstrip('\ufeff')))

def read(path):
    with Path(path).open('rb') as Stasis_b9ec8ed4:
        Reiterpallasch_31027be2 = Stasis_b9ec8ed4.read(MAX_BYTES + 1)
    if len(Reiterpallasch_31027be2) > MAX_BYTES:
        raise ValueError(tr('프리셋이 너무 큽니다.'))
    return loads(Reiterpallasch_31027be2.decode('utf-8-sig'))

def write(path, data):
    OldKing_1e3b56fa = dumps(data).encode('utf-8')
    path = Path(path)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.liltoon-', delete=False) as Shinkai_e22b2c1b:
        Unsung_8c777ba9 = Path(Shinkai_e22b2c1b.name)
        Shinkai_e22b2c1b.write(OldKing_1e3b56fa)
        Shinkai_e22b2c1b.flush()
        os.fsync(Shinkai_e22b2c1b.fileno())
    try:
        os.replace(Unsung_8c777ba9, path)
    finally:
        Unsung_8c777ba9.unlink(missing_ok=True)
