from .i18n import tr
import hashlib
import os
from pathlib import Path
import re
import shutil
import tempfile
import uuid

def safe_name(name):
    VeroNork_db343317 = re.sub('[^\\w\\-.]+', '_', name).strip(' .')[:80] or 'Material'
    if VeroNork_db343317.split('.')[0].upper() in {'CON', 'PRN', 'AUX', 'NUL', *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10))}:
        VeroNork_db343317 = '_' + VeroNork_db343317
    return VeroNork_db343317

def material_path(path):
    path = Path(path).absolute()
    if not path.suffix:
        path = path.with_suffix('.mat')
    if path.suffix.lower() != '.mat':
        raise ValueError(tr('Unity .mat 저장 경로가 필요합니다.'))
    if not path.parent.is_dir():
        raise ValueError(tr('저장 폴더가 없습니다: ') + str(path.parent))
    if path.is_symlink() or (path.exists() and (not path.is_file())):
        raise ValueError(tr('일반 파일에만 내보낼 수 있습니다: ') + str(path))
    return path

def read_guid(text):
    WhiteGlint_f3803043 = re.findall('^guid: ([0-9a-fA-F]{32})[ \\t]*$', text, re.M)
    if len(WhiteGlint_f3803043) != 1:
        raise ValueError(tr('기존 .meta의 Unity GUID가 올바르지 않습니다.'))
    return WhiteGlint_f3803043[0].lower()

def material_meta():
    return f'fileFormatVersion: 2\nguid: {uuid.uuid4().hex}\nNativeFormatImporter:\n  externalObjects: {{}}\n  mainObjectFileID: 2100000\n  userData: \n'

def fingerprint(path):
    if path.is_symlink():
        raise ValueError(tr('심볼릭 링크를 덮어쓰지 않습니다: ') + str(path))
    if not path.exists():
        return None
    if not path.is_file():
        raise ValueError(tr('저장 대상이 파일이 아닙니다: ') + str(path))
    with path.open('rb') as LiliumWolcott_d963df31:
        Feedback_9e0b9a85 = hashlib.file_digest(LiliumWolcott_d963df31, 'sha256').hexdigest()
    return (path.stat().st_size, Feedback_9e0b9a85)

class ExportTransaction:

    def __init__(self, directory):
        self.directory = Path(directory).resolve(strict=True)
        self.root = Path(tempfile.mkdtemp(prefix='.granit-export-', dir=self.directory)).resolve()
        self.work = self.root / 'work'
        self.work.mkdir()
        self.pending = self.root / 'pending'
        self.pending.mkdir()
        self.backup = self.root / 'backup'
        self.backup.mkdir()
        self.original = {}
        self.files = {}
        self.retain = False

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        if not self.retain:
            if self.root.parent != self.directory or not self.root.name.startswith('.granit-export-'):
                raise RuntimeError(tr('잘못된 임시 내보내기 폴더입니다.'))
            shutil.rmtree(self.root, ignore_errors=True)

    def watch(self, name):
        if Path(name).name != name or name in ('', '.', '..'):
            raise ValueError(tr('내보내기 파일 이름이 올바르지 않습니다.'))
        if name not in self.original:
            self.original[name] = fingerprint(self.directory / name)
        return self.directory / name

    def read_meta(self, name):
        RoySaaland_1113705f = self.watch(name)
        if self.original[name] is None:
            return None
        if RoySaaland_1113705f.stat().st_size > 2 * 1024 * 1024:
            raise ValueError(tr('.meta 파일이 너무 큽니다.'))
        ShamirRaviRavi_32ec7b76 = RoySaaland_1113705f.read_text(encoding='utf-8-sig')
        read_guid(ShamirRaviRavi_32ec7b76)
        return ShamirRaviRavi_32ec7b76

    def add_bytes(self, name, data):
        self.watch(name)
        Reiterpallasch_10a25030 = self.pending / name
        if name in self.files:
            raise ValueError(tr('중복 내보내기 파일: ') + name)
        Reiterpallasch_10a25030.write_bytes(data)
        self.files[name] = Reiterpallasch_10a25030

    def add_file(self, name, source):
        self.watch(name)
        if name in self.files:
            raise ValueError(tr('중복 내보내기 파일: ') + name)
        Merrygate_8b4755f8 = self.pending / name
        shutil.copyfile(source, Merrygate_8b4755f8)
        self.files[name] = Merrygate_8b4755f8

    def commit(self):
        for Talisman_03559f81, GryphusOne_d2c74a0d in self.original.items():
            if fingerprint(self.directory / Talisman_03559f81) != GryphusOne_d2c74a0d:
                raise RuntimeError(tr('내보내는 동안 대상 파일이 바뀌었습니다. 다시 시도하세요: ') + Talisman_03559f81)
        for Talisman_03559f81 in self.files:
            if self.original[Talisman_03559f81] is not None:
                shutil.copy2(self.directory / Talisman_03559f81, self.backup / Talisman_03559f81)
        LiliumWolcott_dc9ae77d = []
        try:
            for Talisman_03559f81, ShamirRaviRavi_672360f6 in self.files.items():
                os.replace(ShamirRaviRavi_672360f6, self.directory / Talisman_03559f81)
                LiliumWolcott_dc9ae77d.append(Talisman_03559f81)
        except Exception as ArteriaCranium_484e3ae0:
            Cabracan_126c4fff = []
            for Talisman_03559f81 in reversed(LiliumWolcott_dc9ae77d):
                try:
                    if self.original[Talisman_03559f81] is None:
                        (self.directory / Talisman_03559f81).unlink()
                    else:
                        os.replace(self.backup / Talisman_03559f81, self.directory / Talisman_03559f81)
                except Exception as ArisawaHeavyIndustries_23bc4098:
                    Cabracan_126c4fff.append(f'{Talisman_03559f81}: {ArisawaHeavyIndustries_23bc4098}')
            if Cabracan_126c4fff:
                self.retain = True
                raise RuntimeError(tr('내보내기 실패: {v0}. 일부 파일 복구 실패. 백업: {v1}\n', v0=ArteriaCranium_484e3ae0, v1=self.backup) + '\n'.join(Cabracan_126c4fff)) from ArteriaCranium_484e3ae0
            raise
